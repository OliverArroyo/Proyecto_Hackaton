package com.anas.pizzeria;

import android.content.Intent;
import android.widget.TextView;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.google.api.gax.core.FixedCredentialsProvider;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.dialogflow.v2.*;
import com.google.protobuf.ByteString;
import com.google.protobuf.Value;

import java.io.InputStream;
import java.util.Map;






public class MainActivity extends AppCompatActivity  {

    private SessionsClient sessionsClient;
    private SessionName session;


    private static final int REQUEST_CART_ACTIVITY = 1;
    private List<Pizza> pizzaList;
    private PizzaAdapter pizzaAdapter;

    private int pizzaCount = 0;
    private TextView dialogflowResponse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dialogflowResponse = findViewById(R.id.dialogflowResponse);

        Window window = MainActivity.this.getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.setStatusBarColor(ContextCompat.getColor(MainActivity.this, R.color.colorPrimaryYellow));
        window.setNavigationBarColor(ContextCompat.getColor(MainActivity.this, R.color.colorPrimaryYellow));
        RecyclerView pizzaRecyclerView = findViewById(R.id.pizzaRecyclerView);
        pizzaList = createPizzaList();
        pizzaAdapter = new PizzaAdapter(pizzaList, new PizzaAdapter.PizzaClickListener() {
            @Override
            public void onPlusClick(int position) {
                addPizzaToCart(position);
            }

            @Override
            public void onMinusClick(int position) {
                removePizzaFromCart(position);
            }
        });






        pizzaRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        pizzaRecyclerView.setAdapter(pizzaAdapter);

        Button cartButton = findViewById(R.id.cartButton);
        Button historyButton = findViewById(R.id.historyButton);

        cartButton.setOnClickListener(v -> {
            if (pizzaCount > 0) {
                ArrayList<Pizza> selectedPizzas = new ArrayList<>();
                for (Pizza pizza : pizzaList) {
                    if (pizza.getQuantity() > 0) {
                        selectedPizzas.add(pizza);
                    }
                }
                if (selectedPizzas.size() > 0) {
                    double total = calculateTotal(selectedPizzas);
                    openCartActivity(selectedPizzas, total);
                } else {
                    Toast.makeText(MainActivity.this, "Las Pizzas no han sido añadidas al carrito", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(MainActivity.this, "Las Pizzas no han sido añadidas al carrito", Toast.LENGTH_SHORT).show();
            }
        });

        historyButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, HistoryActivity.class);
            startActivity(intent);
        });
        Button dudasButton = findViewById(R.id.dudasButton);
        dudasButton.setOnClickListener(v -> {
            // Abrir la nueva actividad ChatActivity
            Intent intent = new Intent(MainActivity.this, ChatActivity.class);
            startActivity(intent);
        });


        // Inicializar Dialogflow
        initDialogflow();

        // El resto de tu código en onCreate...
    }

    private List<Pizza> createPizzaList() {
        List<Pizza> pizzas = new ArrayList<>();
        pizzas.add(new Pizza("Combo Crazy Puffs"       , "MXN $179.00"));
        pizzas.add(new Pizza("Pizza de Pepperoni"        , "MXN $129.00"));
        pizzas.add(new Pizza("Pizza 3 Meat Treat"         , "MXN $189.00"));
        pizzas.add(new Pizza("Pizza Ultimate Supreme"      , "MXN $189.00"));
        pizzas.add(new Pizza("Pizza Hula Hawaiian"          , "MXN $179.00"));
        pizzas.add(new Pizza("Creamy Cu4tro"   , "MXN $179.00"));
        pizzas.add(new Pizza("MEXICANA MEXICANA"      , "MXN $179.00"));
        pizzas.add(new Pizza("Pizza de Queso"      , "MXN $119.00"));
        pizzas.add(new Pizza("Crazy combo"  , "MXN $65.00"));
        pizzas.add(new Pizza("Crazy Bread"         , "MXN $49.00"));
        pizzas.add(new Pizza("Canela Stix"    , "MXN $39.00"));
        pizzas.add(new Pizza("Crazy Puffs Pepperoni"   , "MXN $59.00"));
        pizzas.add(new Pizza("Crazy Puffs Hula Hawaiian"   , "MXN $59.00"));
        pizzas.add(new Pizza("Crazy Sauce"         , "MXN $25.00"));
        pizzas.add(new Pizza("Paquete Fiesta"     , "MXN $349.00"));
        pizzas.add(new Pizza("Super-Cheese 3 Meat Treat"      , "MXN $209.00"));
        return pizzas;
    }

    private void addPizzaToCart(int position) {
        Pizza pizza = pizzaList.get(position);
        int quantity = pizza.getQuantity();
        if (quantity < 10) {
            pizzaCount++;
            quantity++;
            pizza.setQuantity(quantity);
            pizzaAdapter.notifyDataSetChanged();
        } else {
            Toast.makeText(this, "El limite de pizzas ha sido alcanzado", Toast.LENGTH_SHORT).show();
        }

    }

    private void removePizzaFromCart(int position) {
        Pizza pizza = pizzaList.get(position);
        int quantity = pizza.getQuantity();
        if (quantity > 0) {
            pizzaCount--;
            quantity--;
            pizza.setQuantity(quantity);
            pizzaAdapter.notifyDataSetChanged();
        } else {
            Toast.makeText(this, "Por favor agregue su orden", Toast.LENGTH_SHORT).show();
        }
    }

    private double calculateTotal(List<Pizza> pizzas) {
        double total = 0;
        for (Pizza pizza : pizzas) {
            int quantity = pizza.getQuantity();
            double price = Double.parseDouble(pizza.getPrice().replaceAll("[^\\d.]+", ""));
            total += (quantity * price);
        }
        return total;
    }



    private void openCartActivity(List<Pizza> selectedPizzas, double total) {
        Intent intent = new Intent(MainActivity.this, CartActivity.class);
        intent.putExtra("selectedPizzas", new ArrayList<>(selectedPizzas));
        intent.putExtra("total", total);
        startActivityForResult(intent, REQUEST_CART_ACTIVITY);
    }

    //Sets the Quantities of pizzas back to 0 once we confirm the order
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CART_ACTIVITY && resultCode == RESULT_OK) {
            ArrayList<Pizza> updatedPizzas = data.getParcelableArrayListExtra("selectedPizzas");
            if (updatedPizzas != null) {
                for (Pizza pizza : pizzaList) {
                    for (Pizza updatedPizza : updatedPizzas) {
                        if (Objects.equals(pizza.getName(), updatedPizza.getName())) {
                            pizza.setQuantity(updatedPizza.getQuantity());
                        }
                    }
                }
                pizzaAdapter.notifyDataSetChanged();
            }
            Intent intent = new Intent(MainActivity.this, HistoryActivity.class);
            startActivity(intent);
        }

    }

    private void initDialogflow() {
        try {
            InputStream stream = getResources().openRawResource(R.raw.chatbot); // Tu archivo de credenciales .json
            GoogleCredentials credentials = GoogleCredentials.fromStream(stream);
            SessionsSettings sessionsSettings = SessionsSettings.newBuilder()
                    .setCredentialsProvider(FixedCredentialsProvider.create(credentials))
                    .build();
            sessionsClient = SessionsClient.create(sessionsSettings);
            session = SessionName.of("your-project-id", "unique-session-id");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private ExecutorService executorService = Executors.newSingleThreadExecutor();

    private void sendMessageToDialogflow(String message) {
        executorService.execute(() -> {
            try {
                // Crear el input de texto para Dialogflow
                TextInput textInput = TextInput.newBuilder().setText(message).setLanguageCode("es").build();
                QueryInput queryInput = QueryInput.newBuilder().setText(textInput).build();

                // Crear y enviar la solicitud a Dialogflow
                DetectIntentRequest detectIntentRequest = DetectIntentRequest.newBuilder()
                        .setSession(session.toString())
                        .setQueryInput(queryInput)
                        .build();

                DetectIntentResponse response = sessionsClient.detectIntent(detectIntentRequest);
                QueryResult queryResult = response.getQueryResult();

                // Depurar para verificar si se recibe la respuesta de Dialogflow
                if (queryResult != null) {
                    Log.d("Dialogflow", "Respuesta recibida: " + queryResult.getFulfillmentText());
                } else {
                    Log.d("Dialogflow", "Respuesta nula de Dialogflow");
                }

                // Volver al hilo principal para actualizar la interfaz de usuario
                runOnUiThread(() -> handleDialogflowResponse(queryResult));

            } catch (Exception e) {
                e.printStackTrace();
                Log.e("Dialogflow", "Error al enviar mensaje: " + e.getMessage());
            }
        });
    }
    private void handleDialogflowResponse(QueryResult queryResult) {
        String fulfillmentText = queryResult.getFulfillmentText();
        // Muestra la respuesta en un Toast
        Toast.makeText(MainActivity.this, fulfillmentText, Toast.LENGTH_LONG).show();
    }

}

