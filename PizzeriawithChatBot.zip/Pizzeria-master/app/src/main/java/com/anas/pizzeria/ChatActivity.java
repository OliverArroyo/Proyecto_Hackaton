package com.anas.pizzeria;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ChatActivity extends AppCompatActivity {

    private EditText userInput;
    private TextView dialogflowResponse;
    private Button sendMessageButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        // Inicializar los elementos de la interfaz
        userInput = findViewById(R.id.userInput);
        dialogflowResponse = findViewById(R.id.dialogflowResponse);
        sendMessageButton = findViewById(R.id.sendMessageButton);

        // Aquí conectas el método de enviar mensaje a Dialogflow (como lo vimos antes)
        sendMessageButton.setOnClickListener(v -> {
            String message = userInput.getText().toString();
            if (!message.isEmpty()) {
                sendMessageToDialogflow(message);  // Enviar el mensaje a Dialogflow
            }
        });
    }

    // Aquí incluyes el código para conectar con Dialogflow (inicialización y envío de mensajes)
    private void sendMessageToDialogflow(String message) {
        // Lógica de Dialogflow que ya habíamos cubierto
        // Una vez que obtengas la respuesta, la muestras en dialogflowResponse
        dialogflowResponse.setText("Respuesta de Dialogflow"); // Actualizar esto con la respuesta real
    }
}